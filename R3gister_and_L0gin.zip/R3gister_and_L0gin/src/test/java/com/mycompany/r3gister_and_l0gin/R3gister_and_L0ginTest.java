/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.r3gister_and_l0gin;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class R3gister_and_L0ginTest {
    
    public R3gister_and_L0ginTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of main method, of class R3gister_and_L0gin.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        R3gister_and_L0gin.main(args);
        // TODO review the generated test code and remove the default call to fail.
     
    }

    /**
     * Test of registerUser method, of class R3gister_and_L0gin.
     */
    @Test
    public void testRegisterUser() {
        System.out.println("registerUser");
        R3gister_and_L0gin.registerUser();
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of loginUser method, of class R3gister_and_L0gin.
     */
    @Test
    public void testLoginUser() {
        System.out.println("loginUser");
        R3gister_and_L0gin.loginUser();
        // TODO review the generated test code and remove the default call to fail.
        
    }
    
}
