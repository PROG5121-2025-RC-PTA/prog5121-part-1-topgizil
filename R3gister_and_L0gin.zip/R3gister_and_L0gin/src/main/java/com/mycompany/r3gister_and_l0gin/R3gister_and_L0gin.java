        /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.r3gister_and_l0gin;
import javax.swing.JOptionPane;
import java.util.HashMap;


/**
 *
 * @author Tebogo Tumelo Tau (ST10473321)
 */
public class R3gister_and_L0gin  {
    
    //USER CLASS TO STORE USER INFO
    static class User  {  
        String username;
        String password;
        String phone;
        
        User(String username,String password, String phone) {
            this.username = username;
            this.password = password;
            this.phone = phone;
        }
    }
    
    //STORES REGISTERED USERS
    static HashMap<String, User> userDatabase = new HashMap<>(); 
    
    public static void main(String[]  args)  {
        OUTER:
        while (true) {
            String[] options ={"Register", "Login", "Exit"};
            int choice = JOptionPane.showOptionDialog(
                    null,
                    "Choose an option",
                    "R3gister_and_L0gin",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    options,
                    options[0]
            );
            switch (choice) {
                case 0 -> registerUser();
                case 1 -> loginUser();
                default -> {
                    JOptionPane.showMessageDialog(null,"Goodbye :)");         
                    break OUTER;
                }
            }
        }
    }
    
    //HANDLES USER REGISTRATION
public static void registerUser() { 
    String username = JOptionPane.showInputDialog("Enter a username(must contain and underscore('_') and no more than 5 characters long)");
    if (username == null || !username.matches("^(?=.*_).{1,6}$"))  {
       
       System.out.println("Username is not correctly formatted,ensure that your username contains an underscore and is no more than 5 characters in length...");
    JOptionPane.showMessageDialog(null,"Username is not correctly formatted, pleaseUsername is not correctly forma ensure that your username contains an underscore and is no more than 5 characters in length..."); 
         return;  
    } else {
       JOptionPane.showMessageDialog(null," Username captured successfully");
       
    }
    
    String password = JOptionPane.showInputDialog("Enter a password(should be atleast 8 characters long, have a special character, number and a capital letter.");
    if (password == null || !isValidPassword(password))  {
        System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character");
    JOptionPane.showMessageDialog(null,"Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character");         
           return;
    } else {
       JOptionPane.showMessageDialog(null,"Password captured successfully.");
      
}
    
    String phone = JOptionPane.showInputDialog("Enter phone number(e.g +27123456789)");
    if (phone == null || !isValidPhoneNumber(phone)) {
        System.out.println("Cell phone number incorrectly formatted or does not contain international code");
    JOptionPane.showMessageDialog(null,"Cell phone number incorrectly formatted or does not contain international code"); 
           return;
    } else {
        JOptionPane.showMessageDialog(null,"Cell phone number successfully added");
        
    }
    
    if (userDatabase.containsKey(username))   {
        JOptionPane.showMessageDialog(null,"Account already exists.");
   } else {
        userDatabase.put(username, new User (username, password, phone ));
        JOptionPane.showMessageDialog(null,"User registered successfully!");    
    }
}

//USER LOGIN
public static void loginUser() {  
    String username = JOptionPane.showInputDialog("Enter username: ");
    String password = JOptionPane.showInputDialog("Enter password: ");
    
    User user = userDatabase.get(username);
    if (user != null && user.password.equals(password)) {
        JOptionPane.showMessageDialog(null," "
                + "Welcome! "  +   username  + " its great to see you again ");
    } else {
        JOptionPane.showMessageDialog(null,"Username or password incorrect please try again");
        
    }
}

//VALIDATES PASSWORD COMPLEXITY
private static boolean isValidPassword(String password)  {
    return password.length() >= 8 &&
           password.matches(".*[A-Z].*") &&
           password.matches(".*[0-9].*") &&
           password.matches(".*[!@#$%^&*()_+=\\-{}|:;\"'<>,.?/].*");
}

//VALIDATES PHONE NUMBER FORMAT
 private static boolean isValidPhoneNumber(String phone) {
    return phone.matches("^\\+27\\d{9}$");

   }
    
}

     